import SwiftUI
import SceneKit
import AppKit

struct ContentView: View {
    @State private var blockCount = 0
    @State private var selectedTool = "Build"
    @State private var showHelp = true

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                Image(systemName: "cube.transparent")
                    .font(.system(size: 25, weight: .bold))
                    .foregroundStyle(.cyan)
                VStack(alignment: .leading, spacing: 2) {
                    Text("BLOCK WORLD")
                        .font(.system(size: 15, weight: .black, design: .rounded))
                        .tracking(2)
                    Text("A tiny 3D sandbox")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Label("\(blockCount) placed", systemImage: "cube.fill")
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(.white.opacity(0.08), in: Capsule())
                Button {
                    NotificationCenter.default.post(name: .resetWorld, object: nil)
                    blockCount = 0
                } label: {
                    Label("Reset world", systemImage: "arrow.counterclockwise")
                }
                .buttonStyle(.bordered)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 14)
            .background(Color(red: 0.075, green: 0.10, blue: 0.14))

            ZStack(alignment: .topLeading) {
                SandboxSceneView(blockCount: $blockCount)
                    .background(Color(red: 0.12, green: 0.19, blue: 0.25))
                if showHelp {
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text("HOW TO PLAY")
                                .font(.caption.weight(.heavy))
                                .tracking(1.2)
                            Spacer()
                            Button {
                                showHelp = false
                            } label: {
                                Image(systemName: "xmark")
                                    .font(.caption.weight(.bold))
                            }
                            .buttonStyle(.plain)
                        }
                        Text("W A S D  ·  Move around")
                        Text("Mouse drag  ·  Orbit camera")
                        Text("Click ground  ·  Place a block")
                        Text("Right-click a block  ·  Remove it")
                        Text("R  ·  Reset world")
                    }
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(13)
                    .background(.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 13))
                    .padding(16)
                }
            }
            HStack {
                Text("Explore • Build • Experiment")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.65))
                Spacer()
                Text("Tip: click the 3D world first to give it keyboard focus")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.5))
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 10)
            .background(Color(red: 0.075, green: 0.10, blue: 0.14))
        }
        .preferredColorScheme(.dark)
    }
}

extension Notification.Name {
    static let resetWorld = Notification.Name("BlockWorldResetWorld")
}

struct SandboxSceneView: NSViewRepresentable {
    @Binding var blockCount: Int

    func makeCoordinator() -> Coordinator { Coordinator(blockCount: $blockCount) }

    func makeNSView(context: Context) -> GameSceneView {
        let view = GameSceneView()
        view.backgroundColor = NSColor(calibratedRed: 0.12, green: 0.19, blue: 0.25, alpha: 1)
        view.antialiasingMode = .multisampling4X
        view.allowsCameraControl = true
        view.autoenablesDefaultLighting = false
        view.delegate = context.coordinator
        view.coordinator = context.coordinator
        context.coordinator.view = view
        context.coordinator.buildWorld()
        NotificationCenter.default.addObserver(
            context.coordinator,
            selector: #selector(Coordinator.resetWorld),
            name: .resetWorld,
            object: nil
        )
        return view
    }

    func updateNSView(_ nsView: GameSceneView, context: Context) {}

    static func dismantleNSView(_ nsView: GameSceneView, coordinator: Coordinator) {
        NotificationCenter.default.removeObserver(coordinator)
    }

    final class Coordinator: NSObject, SCNSceneRendererDelegate {
        @Binding var blockCount: Int
        weak var view: GameSceneView?
        private var player = SCNNode()
        private var cameraNode = SCNNode()
        private var placedBlocks: [SCNNode] = []
        private var heldKeys: Set<UInt16> = []
        private var lastTime: TimeInterval = 0

        init(blockCount: Binding<Int>) {
            _blockCount = blockCount
        }

        func buildWorld() {
            guard let view else { return }
            let scene = SCNScene()
            scene.background.contents = NSColor(calibratedRed: 0.36, green: 0.62, blue: 0.78, alpha: 1)
            view.scene = scene

            let ground = SCNFloor()
            ground.reflectivity = 0
            let groundNode = SCNNode(geometry: ground)
            groundNode.geometry?.firstMaterial?.diffuse.contents = NSColor(calibratedRed: 0.22, green: 0.43, blue: 0.27, alpha: 1)
            groundNode.position = SCNVector3(0, -0.12, 0)
            scene.rootNode.addChildNode(groundNode)

            // A subtle square grid gives the world a buildable, block-based feel.
            for i in -18...18 {
                let xLine = SCNBox(width: 0.012, height: 0.006, length: 36, chamferRadius: 0)
                xLine.firstMaterial?.diffuse.contents = NSColor.white.withAlphaComponent(0.12)
                let xn = SCNNode(geometry: xLine)
                xn.position = SCNVector3(Float(i), -0.105, 0)
                scene.rootNode.addChildNode(xn)

                let zLine = SCNBox(width: 36, height: 0.006, length: 0.012, chamferRadius: 0)
                zLine.firstMaterial?.diffuse.contents = NSColor.white.withAlphaComponent(0.12)
                let zn = SCNNode(geometry: zLine)
                zn.position = SCNVector3(0, -0.104, Float(i))
                scene.rootNode.addChildNode(zn)
            }

            addLight(to: scene, position: SCNVector3(0, 15, 8), intensity: 1250, type: .omni)
            addLight(to: scene, position: SCNVector3(-8, 8, -6), intensity: 650, type: .omni)

            let ambient = SCNNode()
            let ambientLight = SCNLight()
            ambientLight.type = .ambient
            ambientLight.color = NSColor(white: 0.55, alpha: 1)
            ambientLight.intensity = 350
            ambient.light = ambientLight
            scene.rootNode.addChildNode(ambient)

            // Decorative starter structures.
            addBlock(at: SCNVector3(-3, 0.5, -2), color: .systemOrange, countIt: false)
            addBlock(at: SCNVector3(-3, 1.5, -2), color: .systemYellow, countIt: false)
            addBlock(at: SCNVector3(3, 0.5, -3), color: .systemBlue, countIt: false)
            addBlock(at: SCNVector3(3, 1.5, -3), color: .systemTeal, countIt: false)
            addBlock(at: SCNVector3(3, 2.5, -3), color: .systemPurple, countIt: false)

            let playerGeometry = SCNCapsule(capRadius: 0.32, height: 1.35)
            playerGeometry.firstMaterial?.diffuse.contents = NSColor.systemCyan
            player = SCNNode(geometry: playerGeometry)
            player.position = SCNVector3(0, 0.68, 0)
            player.name = "player"
            scene.rootNode.addChildNode(player)

            let camera = SCNCamera()
            camera.fieldOfView = 65
            cameraNode = SCNNode()
            cameraNode.camera = camera
            cameraNode.position = SCNVector3(8, 8, 11)
            cameraNode.look(at: SCNVector3(0, 0, 0))
            scene.rootNode.addChildNode(cameraNode)
            view.pointOfView = cameraNode
        }

        private func addLight(to scene: SCNScene, position: SCNVector3, intensity: CGFloat, type: SCNLight.LightType) {
            let node = SCNNode()
            let light = SCNLight()
            light.type = type
            light.intensity = intensity
            node.light = light
            node.position = position
            scene.rootNode.addChildNode(node)
        }

        private func addBlock(at position: SCNVector3, color: NSColor, countIt: Bool = true) {
            guard let root = view?.scene?.rootNode else { return }
            let box = SCNBox(width: 0.96, height: 0.96, length: 0.96, chamferRadius: 0.035)
            let material = SCNMaterial()
            material.diffuse.contents = color
            material.metalness.contents = 0.08
            material.roughness.contents = 0.72
            box.materials = [material]
            let node = SCNNode(geometry: box)
            node.position = position
            node.name = "buildBlock"
            node.castsShadow = true
            root.addChildNode(node)
            if countIt {
                placedBlocks.append(node)
                DispatchQueue.main.async { self.blockCount = self.placedBlocks.count }
            }
        }

        @objc func resetWorld() {
            placedBlocks.forEach { $0.removeFromParentNode() }
            placedBlocks.removeAll()
            player.position = SCNVector3(0, 0.68, 0)
            DispatchQueue.main.async { self.blockCount = 0 }
        }

        func keyDown(_ event: NSEvent) {
            heldKeys.insert(event.keyCode)
            if event.keyCode == 15 { resetWorld() } // R
        }

        func keyUp(_ event: NSEvent) {
            heldKeys.remove(event.keyCode)
        }

        func mouseDown(at point: CGPoint) {
            guard let view, let scene = view.scene else { return }
            let hits = view.hitTest(point, options: [.searchMode: SCNHitTestSearchMode.closest.rawValue])
            if let hit = hits.first, hit.node.name == "buildBlock" {
                return
            }
            let floorHits = view.hitTest(point, options: nil)
            guard let hit = floorHits.first(where: { $0.node.geometry is SCNFloor }) else { return }
            let p = hit.worldCoordinates
            let x = round(p.x)
            let z = round(p.z)
            let y = 0.5
            let colors: [NSColor] = [.systemOrange, .systemBlue, .systemPurple, .systemGreen, .systemPink, .systemYellow]
            let color = colors[placedBlocks.count % colors.count]
            addBlock(at: SCNVector3(x, CGFloat(y), z), color: color)
            _ = scene
        }

        func rightMouseDown(at point: CGPoint) {
            guard let view else { return }
            let hits = view.hitTest(point, options: nil)
            if let node = hits.first(where: { $0.node.name == "buildBlock" })?.node {
                node.removeFromParentNode()
                placedBlocks.removeAll { $0 === node }
                DispatchQueue.main.async { self.blockCount = self.placedBlocks.count }
            }
        }

        func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
            let delta = lastTime == 0 ? 0 : min(time - lastTime, 0.05)
            lastTime = time
            guard delta > 0 else { return }
            let speed: CGFloat = CGFloat(delta) * 5
            var dx: CGFloat = 0
            var dz: CGFloat = 0
            if heldKeys.contains(13) || heldKeys.contains(126) { dz -= speed } // W / up
            if heldKeys.contains(1) || heldKeys.contains(125) { dz += speed }  // S / down
            if heldKeys.contains(0) || heldKeys.contains(123) { dx -= speed }  // A / left
            if heldKeys.contains(2) || heldKeys.contains(124) { dx += speed }  // D / right
            if dx != 0 || dz != 0 {
                player.position.x = max(-17, min(17, player.position.x + dx))
                player.position.z = max(-17, min(17, player.position.z + dz))
            }
        }
    }
}

final class GameSceneView: SCNView {
    weak var coordinator: SandboxSceneView.Coordinator?

    override var acceptsFirstResponder: Bool { true }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        window?.makeFirstResponder(self)
    }

    override func keyDown(with event: NSEvent) {
        coordinator?.keyDown(event)
    }

    override func keyUp(with event: NSEvent) {
        coordinator?.keyUp(event)
    }

    override func mouseDown(with event: NSEvent) {
        window?.makeFirstResponder(self)
        let point = convert(event.locationInWindow, from: nil)
        coordinator?.mouseDown(at: point)
    }

    override func rightMouseDown(with event: NSEvent) {
        let point = convert(event.locationInWindow, from: nil)
        coordinator?.rightMouseDown(at: point)
    }
}
