# Block World — macOS 3D Sandbox

A small native macOS sandbox game built with SwiftUI and SceneKit.

## Controls

- **W A S D** or arrow keys: move the cyan player
- **Drag with the mouse**: orbit the camera
- **Click the ground**: place a block
- **Right-click a placed block**: remove it
- **R**: reset the world
- **Reset world** button: remove all placed blocks and return the player to the start

Click the 3D scene first to give it keyboard focus.

## Build from an iPad using GitHub Actions

1. Create a new GitHub repository named `BlockWorld`.
2. Upload all files and folders from this project. Make sure `.github/workflows/build-dmg.yml` is included.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Choose **Build Block World DMG** and tap **Run workflow** (or let the first push start it).
6. When the workflow finishes, open the run and download the `BlockWorld-macOS-DMG` artifact.
7. Unzip the artifact to get `BlockWorld.dmg`.

## Important notes

- The workflow builds an unsigned app and packages it into a DMG. It does not sign or notarize the app.
- On another Mac, Gatekeeper may warn because the app is not signed/notarized. Only open apps you built and trust.
- For public distribution without Gatekeeper warnings, a developer signing identity and Apple notarization are normally needed.
- GitHub-hosted macOS runners are temporary build machines, not permanent Mac servers.
